package C;

public class Principal {
    public static void main(String a[]){
        AmbienteEspacial b = new AmbienteEspacial();

        b.menu();
    }
}
