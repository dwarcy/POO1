package C;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Principal {
    public static void main(String[] args){
        int vet[] = new int[4];
        Scanner leitor = new Scanner(System.in);
        int valor, posicao;
        int ct = 0;

        do {
            try{
                System.out.println("Valor: ");
                valor = leitor.nextInt();
                System.out.println("Posicao: ");
                posicao = leitor.nextInt();
                leitor.nextLine();
                vet[posicao] = valor;
                ct++;
            }catch (IndexOutOfBoundsException e){
                System.out.println("Posicao Invalida.");
            }catch (InputMismatchException e){
                System.out.println("Valor Invalido.");
                leitor.nextLine();
            }
        }while (ct <= 3);

        for (int i=0; i<ct; i++){
            System.out.println(vet[i]);
        }
    }
}
