package B;

public class SistemaExcecao extends Exception{
    public SistemaExcecao(String msg){
        super(msg);
    }
    public SistemaExcecao(){
        super();
    }
}
